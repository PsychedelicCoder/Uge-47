import java.sql.*;

public class MainController {

    /*
   Create a connection to your local instance world database.
- The URL should look like this: "jdbc:mysql://localhost/world"
- Create the connection like this:
Connection connection = null;
connection = DriverManager.getConnection(URL, username, password);
- NOTE: the second line in the above step, must be in a try/catch. - ALSO NOTE: You have to define String username and String password with your MySQL login (root/<password>)
- THIRD NOTE: If you're having trouble finding the correct driver for the JDBC, try the following and use the one, that doesn't have "bin" in the name:
     */

    public void runProgram() {
        getConnection();


    }

    public void () {

        String sql = "";
        Statement stmt = null;
        ResultSet res = null;

        sql = "";
        Connection con = getConnection();
        try {
            stmt = con.createStatement();
            res = stmt.executeQuery(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

        public Connection getConnection () {
            Connection con = null;
            String user = "root";
            String password = "root123";
            String urlAddOn = "?serverTimezone=UTC&allowPublicKeyRetrieval=true&useSSL=false";
            String url = "jdbc:mysql://localhost/world" + urlAddOn;
            try {
                con = DriverManager.getConnection(url, user, password);

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return con;
        }
    }
